package com.yunkong.monitor.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

// 终端风格强调色（对齐 CF-Server-Monitor 原项目）
val Green = Color(0xFF00D4AA)
val Red = Color(0xFFF85149)
val Amber = Color(0xFFFFB870)
val BrandBlue = Color(0xFF4DA6FF)
val Cyan = Color(0xFF39D2C0)
val Purple = Color(0xFFB392F0)
val Pink = Color(0xFFF778BA)

/** 原项目终端风格调色板（深浅主题各一套） */
data class TermPalette(
    val bg: Color,
    val surface: Color,
    val border: Color,
    val text: Color,
    val textSec: Color,
    val green: Color,
    val blue: Color,
    val purple: Color,
    val pink: Color,
    val yellow: Color,
    val red: Color,
    val cyan: Color
)

private val DarkTerm = TermPalette(
    bg = Color(0xFF0A0E14),
    surface = Color(0xFF121720),
    border = Color(0xFF1E2A3A),
    text = Color(0xFFD3DAE3),
    textSec = Color(0xFF8999AF),
    green = Green, blue = BrandBlue, purple = Purple, pink = Pink,
    yellow = Amber, red = Red, cyan = Cyan
)

private val LightTerm = TermPalette(
    bg = Color(0xFFF5F5F0),
    surface = Color(0xFFFAFAF5),
    border = Color(0xFFD4D4C8),
    text = Color(0xFF2C2C2C),
    textSec = Color(0xFF5C5C5C),
    green = Color(0xFF1A7F5A), blue = Color(0xFF2563EB), purple = Color(0xFF7C3AED),
    pink = Color(0xFFDB2777), yellow = Color(0xFFD97706), red = Color(0xFFDC2626),
    cyan = Color(0xFF0D9488)
)

val LocalTerm = staticCompositionLocalOf { DarkTerm }

@Composable
fun term(): TermPalette = LocalTerm.current

private val LightColors = lightColorScheme(
    primary = Color(0xFF0D9488),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCCECE7),
    onPrimaryContainer = Color(0xFF0B3B36),
    secondary = Color(0xFF2563EB),
    background = Color(0xFFF5F5F0),
    onBackground = Color(0xFF2C2C2C),
    surface = Color(0xFFFAFAF5),
    onSurface = Color(0xFF2C2C2C),
    surfaceVariant = Color(0xFFECECE4),
    onSurfaceVariant = Color(0xFF5C5C5C),
    outline = Color(0xFFD4D4C8),
    error = Color(0xFFDC2626)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF39D2C0),
    onPrimary = Color(0xFF062420),
    primaryContainer = Color(0xFF16413C),
    onPrimaryContainer = Color(0xFFB8F2EA),
    secondary = Color(0xFF4DA6FF),
    background = Color(0xFF0A0E14),
    onBackground = Color(0xFFD3DAE3),
    surface = Color(0xFF121720),
    onSurface = Color(0xFFD3DAE3),
    surfaceVariant = Color(0xFF0F1620),
    onSurfaceVariant = Color(0xFF8999AF),
    outline = Color(0xFF1E2A3A),
    error = Color(0xFFF85149)
)

val GlassShapes = Shapes(
    extraSmall = RoundedCornerShape(10.dp),
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun YunKongTheme(themeMode: Int, content: @Composable () -> Unit) {
    val dark = when (themeMode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    CompositionLocalProvider(LocalTerm provides if (dark) DarkTerm else LightTerm) {
        MaterialTheme(
            colorScheme = if (dark) DarkColors else LightColors,
            shapes = GlassShapes,
            content = content
        )
    }
}
